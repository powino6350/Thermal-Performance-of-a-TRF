#!/usr/bin/env python3
# ==============================================================================
# Script: Extract_Thermal_Fields.py
# Description: Processes numerical thermal simulation logs for the Tilting 
#              Rotary Furnace (TRF). Computes radial temperature gradients, 
#              heat flux profiles, and core heating rates across virtual TCs.
# ==============================================================================

import json
import pandas as pd
import numpy as np


def load_material_properties(json_path):
    """Loads thermophysical properties from JSON configuration."""
    with open(json_path, 'r') as f:
        data = json.load(f)
    return pd.DataFrame(data['materials'])


def process_thermal_logs(csv_path):
    """Parses transient thermocouple logs and calculates thermal gradients."""
    df = pd.read_csv(csv_path)

    # Temperature difference between Core (TC-C) and Shell (TC-S)
    df['Delta_T_Core_Shell'] = df['TC_C_Temp_C'] - df['TC_S_Temp_C']

    # Radial gradient across crucible wall (TC-C to TC-I)
    df['Delta_T_Crucible'] = df['TC_C_Temp_C'] - df['TC_I_Temp_C']

    # Heating rate (deg C / s) computed as forward difference
    df['Heating_Rate_C_s'] = df.groupby('Replicate_ID')['TC_C_Temp_C'].diff() / df.groupby('Replicate_ID')['Time_s'].diff()

    return df


def generate_summary_metrics(df):
    """Calculates steady-state summary metrics for statistical testing."""
    steady_state_df = df[df['Time_s'] >= 100]  # Thermal equilibrium threshold

    summary = steady_state_df.groupby(['Material', 'Shape', 'Thickness_mm', 'Tilt_deg']).agg(
        Mean_Peak_Core_Temp=('TC_C_Temp_C', 'mean'),
        Std_Peak_Core_Temp=('TC_C_Temp_C', 'std'),
        Mean_Shell_Temp=('TC_S_Temp_C', 'mean'),
        Mean_Heat_Flux=('Surface_Heat_Flux_W_m2', 'mean')
    ).reset_index()

    return summary


if __name__ == "__main__":
    print("--- TRF Thermal Field Extraction Pipeline ---")
    
    # Example relative paths based on repository structure
    mat_props = load_material_properties("../Simulation_Data/Material_Properties.json")
    print(f"Loaded {len(mat_props)} material property sets.")

    logs_df = process_thermal_logs("../Simulation_Data/Transient_Thermal_Logs.csv")
    print(f"Processed {len(logs_df)} time-series logs.")

    metrics = generate_summary_metrics(logs_df)
    print("\nSummary Metrics (Steady State):")
    print(metrics.to_string(index=False))