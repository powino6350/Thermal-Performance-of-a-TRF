# ==============================================================================
# Script: generate_TRF_STEP.py
# Description: Generates CAD_Models/TRF_Assembly_Step.step based on manuscript
#              Section 2.2 specifications for Tilting Rotary Furnace (TRF).
# ==============================================================================

import cadquery as cq

# --- Geometric Parameters (in millimeters) ---
L_furnace = 670.0      # Furnace Length (670 mm)
R_outer = 300.0        # Outer Outer Diameter / 2 (600 mm / 2)
t_steel = 15.0         # A36 Steel Shell Thickness (15 mm)
t_sand = 100.0         # Sand Insulation Thickness (100 mm)
t_refractory = 15.0    # Refractory Backing Thickness (15 mm)
t_crucible = 10.0      # Graphite Crucible Wall Thickness (10 mm)

# Calculated Radii
R_steel_in = R_outer - t_steel                      # 285 mm
R_sand_in = R_steel_in - t_sand                     # 185 mm
R_ref_in = R_sand_in - t_refractory                 # 170 mm
R_crucible_in = R_ref_in - t_crucible               # 160 mm

# --- 1. Outer A36 Steel Casing ---
steel_casing = (
    cq.Workplane("XY")
    .circle(R_outer)
    .circle(R_steel_in)
    .extrude(L_furnace)
)

# --- 2. Sand Insulation Layer ---
sand_insulation = (
    cq.Workplane("XY")
    .circle(R_steel_in)
    .circle(R_sand_in)
    .extrude(L_furnace)
)

# --- 3. Refractory Backing Lining ---
refractory_lining = (
    cq.Workplane("XY")
    .circle(R_sand_in)
    .circle(R_ref_in)
    .extrude(L_furnace)
)

# --- 4. Interchangeable Graphite Crucible (10mm Cylindrical) ---
crucible_body = (
    cq.Workplane("XY")
    .circle(R_ref_in)
    .circle(R_crucible_in)
    .extrude(L_furnace)
)

# --- 5. Combine Into Assembly ---
trf_assembly = cq.Assembly()
trf_assembly.add(steel_casing, name="A36_Steel_Shell", color=cq.Color("Gray"))
trf_assembly.add(sand_insulation, name="Sand_Insulation_Layer", color=cq.Color("Yellow"))
trf_assembly.add(refractory_lining, name="Refractory_Backing", color=cq.Color("Red"))
trf_assembly.add(crucible_body, name="Graphite_Crucible_10mm", color=cq.Color("Black"))

# --- 6. Export STEP Neutral File ---
trf_assembly.save("TRF_Assembly_Step.step")
print("Successfully generated: CAD_Models/TRF_Assembly_Step.step")