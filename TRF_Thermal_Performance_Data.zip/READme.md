# Thermal Performance and Geometry Optimization of a Tilting Rotary Furnace (TRF)

[!\[License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[!\[Language: Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)](https://www.python.org/)
[!\[Language: R](https://img.shields.io/badge/R-4.0%2B-green.svg)](https://www.r-project.org/)
[!\[CAD: Fusion 360 / STEP](https://img.shields.io/badge/CAD-Fusion360%20%7C%20STEP-red.svg)](https://www.autodesk.com/products/fusion-360)

This repository contains the computational models, transient thermal logs, geometry extraction pipelines, and statistical analysis scripts for the study on optimizing the thermal efficiency, crucible geometry, and material selection of a Tilting Rotary Furnace (TRF).

\---

## 📁 Repository Structure

```text
Thermal-Performance-of-a-TRF/
├── CAD\_Models/
│   ├── TRF\_3D\_Assembly.f3d          # Autodesk Fusion 360 parametric source model
│   └── TRF\_Assembly\_Step.step        # Neutral STEP exchange file for open-source CAD
├── Simulation\_Data/
│   ├── Material\_Properties.json     # Thermophysical properties matrix
│   └── Transient\_Thermal\_Logs.csv   # 10-second thermocouple log data (N=10 runs)
├── Scripts/
│   ├── Extract\_Thermal\_Fields.py    # Python extraction pipeline for spatial thermal metrics
│   └── Statistical\_ANOVA.R          # R script for Two-Way ANOVA and Tukey HSD tests
├── LICENSE                          # MIT Open Source License
└── README.md                        # Documentation and replication guide

Geometric & Material SpecificationsOuter Casing: Cylindrical A36 structural steel shell ($L = 670\text{ mm}$, $\varnothing = 600\text{ mm}$, wall thickness $t_s = 15\text{ mm}$).Insulation Layers: Intermediate sand insulation ($100\text{ mm}$, $k = 0.25\text{ W m}^{-1}\text{K}^{-1}$) and dense refractory backing ($15\text{ mm}$).Crucible Options: Graphite (default $10\text{ mm}$ wall), Silicon Carbide (SiC), Advanced Ceramics, and Fired Clay Brick across cylindrical, conical, flat-base, and sharp-corner profiles.Virtual Thermocouples:TC-C: Core / Charge CenterTC-I: Interior Near-WallTC-S: Exterior Shell Boundary🚀 Quick Start & Reproduction1. Extract Thermal Fields (Python)Ensure Python 3.8+ and Pandas/Numpy are installed:Bashpython Scripts/Extract_Thermal_Fields.py
2. Statistical Analysis (R)Run two-way ANOVA and Tukey HSD post-hoc evaluation:BashRscript Scripts/Statistical_ANOVA.R
📜 Citation & LicenseThis project is licensed under the MIT License. If you utilize these models or datasets in your research, please cite the main manuscript accordingly.
---

### Step-by-Step Instructions to Upload to GitHub

1. Navigate to your repository root: `[https://github.com/powino6350/Thermal-Performance-of-a-TRF](https://github.com/powino/Thermal-Performance-of-a-TRF)`[cite: 3].
2. Click **Add file** $\rightarrow$ **Create new file**.
3. In the filename box, type: `LICENSE`.
4. Paste the MIT License text above and click **Commit changes...**.
5. Repeat for `README.md` in the root directory.

With this completed, your entire repository structure (`CAD_Models/`, `Simulation_Data/`, `Scripts/`, `README.md`, and `LICENSE`) is fully organized, functional, and ready for publication[cite: 3]!